// 侧边栏脚本 - 负责渲染 Markdown

const debug = true;

// DOM 元素引用
const markdownOutput = document.getElementById('markdown-output');
const timestampElement = document.getElementById('timestamp');
const logMessages = document.getElementById('log-messages');
const debugConsole = document.getElementById('debug-console');
const refreshButton = document.getElementById('refresh-btn');
const toggleLogButton = document.getElementById('toggle-log-btn');
const clearLogButton = document.getElementById('clear-log-btn');
const pinButton = document.getElementById('pin-btn');

// 状态变量
let isDebugVisible = false;
let isAccessibilityModeEnabled = false;
let isPinned = true; // 默认开启置顶状态

// 日志函数
function logMessage(source, message) {
  if (debug) {
    const timestamp = new Date().toLocaleTimeString();
    console.log(`[SidePanel] [${source}] ${message}`);
    
    const logEntry = document.createElement('p');
    
    const timestampSpan = document.createElement('span');
    timestampSpan.textContent = timestamp;
    timestampSpan.className = 'timestamp';
    
    const sourceSpan = document.createElement('span');
    sourceSpan.textContent = `[${source}]`;
    
    // 根据来源设置样式
    if (source === 'background') {
      sourceSpan.className = 'log-background';
    } else if (source === 'content') {
      sourceSpan.className = 'log-content';
    } else if (source === 'error') {
      sourceSpan.className = 'log-error';
    }
    
    const messageSpan = document.createElement('span');
    messageSpan.textContent = ` ${message}`;
    messageSpan.className = 'log-message-content';
    
    logEntry.appendChild(timestampSpan);
    logEntry.appendChild(document.createTextNode(' '));
    logEntry.appendChild(sourceSpan);
    logEntry.appendChild(messageSpan);
    
    logMessages.appendChild(logEntry);
    logMessages.scrollTop = logMessages.scrollHeight;
  }
}

// 切换置顶状态
function togglePinStatus() {
  isPinned = !isPinned;
  
  // 更新按钮样式
  if (isPinned) {
    pinButton.classList.add('pinned');
    markdownOutput.classList.remove('hidden');
    logMessage('sidepanel', '置顶状态开启，markdown区域展开');
    
    // 通知背景脚本恢复监听
    chrome.runtime.sendMessage({
      type: 'start_listening'
    }).then(response => {
      logMessage('sidepanel', `内容脚本监听已恢复: ${JSON.stringify(response)}`);
    }).catch(err => {
      logMessage('sidepanel', `恢复内容脚本监听失败: ${err.message}`);
    });
  } else {
    pinButton.classList.remove('pinned');
    markdownOutput.classList.add('hidden');
    logMessage('sidepanel', '置顶状态关闭，markdown区域收起');
    
    // 立即通知背景脚本关闭侧边栏
    logMessage('sidepanel', '准备发送关闭侧边栏请求');
    chrome.runtime.sendMessage({
      type: 'close_sidepanel'
    }).then(response => {
      logMessage('sidepanel', `关闭侧边栏请求已发送，响应: ${JSON.stringify(response)}`);
    }).catch(err => {
      logMessage('sidepanel', `通知关闭侧边栏失败: ${err.message}`);
    });
  }
  
  // 保存状态到chrome.storage
  chrome.storage.local.set({ isPinned: isPinned }, () => {
    logMessage('sidepanel', `置顶状态已保存: ${isPinned}`);
  });
}

// 设置无障碍模式
function setAccessibilityMode(enabled) {
  isAccessibilityModeEnabled = enabled;
  
  // 更新界面
  if (enabled) {
    document.body.classList.add('accessibility-mode');
    logMessage('sidepanel', '无障碍模式已启用');
  } else {
    document.body.classList.remove('accessibility-mode');
    logMessage('sidepanel', '无障碍模式已禁用');
  }
  
  // 添加或更新状态指示器
  let statusIndicator = document.getElementById('accessibility-status');
  if (!statusIndicator) {
    statusIndicator = document.createElement('div');
    statusIndicator.id = 'accessibility-status';
    document.querySelector('.header-info').appendChild(statusIndicator);
  }
  
  statusIndicator.textContent = enabled ? '无障碍模式: 开启' : '';
  statusIndicator.style.display = enabled ? 'block' : 'none';
  
  // 如果已经渲染了内容，重新应用样式
  if (markdownOutput.innerHTML && !markdownOutput.querySelector('.empty-state')) {
    applyAccessibilityStyles();
  }
}

// 应用无障碍样式到渲染的内容
function applyAccessibilityStyles() {
  if (!isAccessibilityModeEnabled) return;
  
  // 为所有内容元素添加无障碍样式
  const elements = markdownOutput.querySelectorAll('p, h1, h2, h3, h4, h5, h6, li, td, th, code, pre');
  elements.forEach(el => {
    // 增加行间距
    el.style.lineHeight = '1.8';
    
    // 确保足够的文本大小
    if (window.getComputedStyle(el).fontSize < '16px') {
      el.style.fontSize = '16px';
    }
    
    // 增加文本对比度
    el.style.color = '#000000';
    
    // 确保背景与文本有足够对比度
    if (el.tagName === 'CODE' || el.tagName === 'PRE') {
      el.style.backgroundColor = '#f8f8f8';
      el.style.border = '1px solid #e0e0e0';
      el.style.padding = '0.5rem';
    }
  });
  
  // 确保链接可识别
  const links = markdownOutput.querySelectorAll('a');
  links.forEach(link => {
    link.style.textDecoration = 'underline';
    link.style.color = '#0066cc';
    link.style.fontWeight = 'bold';
  });
  
  // 确保图片有替代文本
  const images = markdownOutput.querySelectorAll('img:not([alt])');
  images.forEach(img => {
    img.alt = '图片内容';
  });
}

// 渲染 Markdown 内容
function renderMarkdown(content, timestamp, accessibilityMode) {
  // 如果提供了无障碍模式设置，先更新它
  if (accessibilityMode !== undefined) {
    setAccessibilityMode(accessibilityMode);
  }
  
  if (!content) {
    logMessage('sidepanel', '收到空内容，不进行渲染');
    
    // 显示空状态
    markdownOutput.innerHTML = `
      <div class="empty-state">
        <svg xmlns="http://www.w3.org/2000/svg" height="48" width="48" viewBox="0 0 24 24">
          <path d="M14.06 9.02l.92.92L5.92 19H5v-.92l9.06-9.06M17.66 3c-.25 0-.51.1-.7.29l-1.83 1.83 3.75 3.75 1.83-1.83c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.2-.2-.45-.29-.71-.29zm-3.6 3.19L3 17.25V21h3.75L17.81 9.94l-3.75-3.75z" />
        </svg>
        <p>点击腾讯文档中的单元格来查看其 Markdown 渲染效果</p>
        <p class="shortcut-hint">提示: 使用 Ctrl+~ 切换无障碍模式</p>
      </div>
    `;
    timestampElement.textContent = '';
    return;
  }
  
  try {
    logMessage('sidepanel', `渲染 Markdown 内容，长度: ${content.length}`);
    
    // 解析 Markdown 为 HTML
    let rawHtml;
    try {
      rawHtml = marked.parse(content);
    } catch (error) {
      logMessage('error', `Markdown 解析错误: ${error.message}`);
      showError(`Markdown 解析错误: ${error.message}`);
      return;
    }
    
    // 清理生成的 HTML (防止 XSS)
    let cleanHtml;
    try {
      cleanHtml = DOMPurify.sanitize(rawHtml);
    } catch (error) {
      logMessage('error', `HTML 清理错误: ${error.message}`);
      showError(`HTML 清理错误: ${error.message}`);
      return;
    }
    
    // 渲染到页面
    markdownOutput.innerHTML = cleanHtml;
    
    // 如果无障碍模式启用，应用样式
    if (isAccessibilityModeEnabled) {
      applyAccessibilityStyles();
    }
    
    // 检查置顶状态，如果置顶关闭则保持隐藏
    if (!isPinned) {
      markdownOutput.classList.add('hidden');
    }
    
    // 如果有时间戳，显示它
    if (timestamp) {
      timestampElement.textContent = `更新时间: ${timestamp}`;
    } else {
      timestampElement.textContent = `更新时间: ${new Date().toLocaleString()}`;
    }
    
    logMessage('sidepanel', '渲染完成');
  } catch (error) {
    logMessage('error', `渲染过程中发生错误: ${error.message}`);
    showError(`渲染过程中发生错误: ${error.message}`);
  }
}

// 显示错误信息
function showError(message) {
  markdownOutput.innerHTML = `
    <div class="error-state">
      <strong>错误:</strong> ${message}
    </div>
  `;
}

// 重新加载侧边栏
function reloadSidePanel() {
  logMessage('sidepanel', '重新加载侧边栏');
  window.location.reload();
}

// 切换调试控制台的可见性
function toggleDebugConsole() {
  isDebugVisible = !isDebugVisible;
  
  if (isDebugVisible) {
    debugConsole.classList.remove('hidden');
  } else {
    debugConsole.classList.add('hidden');
  }
  
  logMessage('sidepanel', `调试控制台 ${isDebugVisible ? '显示' : '隐藏'}`);
}

// 清除日志
function clearLogs() {
  logMessages.innerHTML = '';
  logMessage('sidepanel', '日志已清除');
}

// 初始化侧边栏
function initializeSidePanel() {
  logMessage('sidepanel', '侧边栏初始化');
  
  // 确保调试控制台默认隐藏
  debugConsole.classList.add('hidden');
  
  // 从 chrome.storage.local 获取最后的内容和设置
  chrome.storage.local.get(['lastMarkdownContent', 'timestamp', 'accessibilityMode', 'isPinned'], function(data) {
    // 设置置顶状态
    if (data.isPinned !== undefined) {
      isPinned = data.isPinned;
    }
    
    // 更新置顶按钮状态
    if (isPinned) {
      pinButton.classList.add('pinned');
      markdownOutput.classList.remove('hidden');
    } else {
      pinButton.classList.remove('pinned');
      markdownOutput.classList.add('hidden');
    }
    
    // 设置无障碍模式
    if (data.accessibilityMode !== undefined) {
      setAccessibilityMode(data.accessibilityMode);
    }
    
    if (data.lastMarkdownContent && isPinned) {
      logMessage('sidepanel', `从存储中加载上次的内容 (${data.timestamp})`);
      renderMarkdown(data.lastMarkdownContent, data.timestamp);
    }
  });
  
  // 通知背景脚本侧边栏已初始化
  chrome.runtime.sendMessage({ type: 'sidePanel_initialized' }, function(response) {
    logMessage('sidepanel', `背景脚本响应初始化: ${JSON.stringify(response)}`);
  });
}

// 设置事件监听器
function setupEventListeners() {
  // 监听来自背景脚本的消息
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'render_markdown') {
      renderMarkdown(message.content, message.timestamp, message.accessibilityMode);
      sendResponse({ status: 'rendered' });
      return true;
    }
    
    if (message.type === 'update_accessibility') {
      setAccessibilityMode(message.enabled);
      sendResponse({ status: 'updated' });
      return true;
    }
    
    if (message.type === 'log') {
      logMessage(message.source, message.message);
      sendResponse({ status: 'logged' });
      return true;
    }
    
    return false;
  });
  
  // 刷新按钮点击
  refreshButton.addEventListener('click', reloadSidePanel);
  
  // 切换日志按钮点击
  toggleLogButton.addEventListener('click', toggleDebugConsole);
  
  // 清除日志按钮点击
  clearLogButton.addEventListener('click', clearLogs);
  
  // 置顶按钮点击
  pinButton.addEventListener('click', togglePinStatus);
  
  // 监听键盘快捷键
  document.addEventListener('keydown', event => {
    // Ctrl+R 或 Cmd+R 重新加载侧边栏
    if ((event.ctrlKey || event.metaKey) && event.key === 'r') {
      event.preventDefault();
      reloadSidePanel();
    }
    
    // Ctrl+` 或 Cmd+` 切换无障碍模式
    if ((event.ctrlKey || event.metaKey) && event.key === '`') {
      event.preventDefault();
      // 通知背景脚本切换无障碍模式
      chrome.runtime.sendMessage({ type: 'toggle_accessibility' }, response => {
        if (response && response.status === 'toggled') {
          setAccessibilityMode(response.enabled);
        }
      });
    }
  });
}

// 启动侧边栏
function start() {
  try {
    setupEventListeners();
    initializeSidePanel();
  } catch (error) {
    console.error('侧边栏启动错误:', error);
    showError(`侧边栏启动失败: ${error.message}`);
  }
}

// 启动
start(); 